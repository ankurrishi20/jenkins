var flow_steps = require("./user_mgmt_flow.json");
//var flow_comp = require("./user_mgmt_component.json");
var form_data = require("./user_mgmt_data.json");
var form_selector = require("./user_mgmt_formselector.json");
var nav = require("./navigation.json");
var formglobalindex = 0;
var sectionglobalindex = 1;
var globalpon = "";
var actiononorder
var EC = protractor.ExpectedConditions;

var GenericFlow = function() {

    getValueDate = function(days) {
        var today = new Date();
        var dd = today.getDate();
        console.log("Today $$$$$$$$    " + dd)

        var mm = today.getMonth() + 1; //January is 0!var flow_steps = require("./user_mgmt_flow.json");
        //var flow_comp = require("./user_mgmt_component.json");
        var form_data = require("./user_mgmt_data.json");
        var form_selector = require("./user_mgmt_formselector.json");
        var nav = require("./navigation.json");
        var formglobalindex = 0;
        var sectionglobalindex = 1;
        var globalpon = "";
        var actiononorder

        var GenericFlow = function() {

            

            getValueDate = function(days) {
                var today = new Date();
                var dd = today.getDate();
                console.log("Today $$$$$$$$    " + dd)

                var mm = today.getMonth() + 1; //January is 0!
                if (dd >= 23) {
                    dd = 0;
                    dd = dd + parseInt(days)
                    mm = mm + 1;

                } else {
                    dd = dd + parseInt(days)
                }

                var yyyy = today.getFullYear();
                if (dd < 10) {
                    dd = '0' + dd
                }
                if (mm < 10) {
                    mm = '0' + mm
                }
                var today = mm + '-' + dd + '-' + yyyy;
                console.log("today is: " + today)
                return today

            }

            getValuePON = function(data) {

                globalpon = data + Math.floor((Math.random() * 1000000) + 1);
                return globalpon;
            }


            /*this.flow = function(selectFlow, type, data){
                ////console.log(flow_steps);
                data = eval("form_data."+data);
                var flow = eval("flow_steps."+selectFlow);
                ////console.log("flow_steps."+selectFlow);
                
                
                for(var key in flow)
                {
                    ////console.log(key);
                    var component = flow[key];
                    ////console.log(component);
                    this.flowControl(flow_comp[type+"_comp"][component], type, data);
                }
            };*/

            this.flow = function(selectFlow, type) {
                //console.log(flow_steps);      
        var flow = eval("flow_steps."+selectFlow+"."+type);
        console.log("flow_steps."+type);
        this.flowControl(flow, type);

            };

            this.buttonText = function(key, value) {
                element(by.buttonText(key)).sendKeys(value);
                browser.waitForAngular();
            }
            this.model = function(key, value) {
                element(by.model(key)).sendKeys(value);
                browser.waitForAngular();
            }

            this.modelSet = function(modelArray) {
                for (var key in modelArray) {
                    var model = modelArray[key];
                    if (model.key instanceof Object)
                        element.all(by.model(model.key)).get()
                    this.model(model.key, model.value);
                }
            }

            this.repeater = function(flow) {
                var cmd = "by.repeater('" + flow.selector.repeater + "')";
                if (flow.repeater != undefined && flow.repeater.row != undefined)
                    cmd += ".row(" + parseInt(flow.repeater.row) + ")";
                if (flow.repeater != undefined && flow.repeater.column != undefined)
                    cmd += ".column(" + flow.repeater.column + ")";
                return cmd;
            }

            this.css = function(flow) {
                /*var classattr = "";
                if(flow.selector.class!=undefined){
                    classattr+="."+flow.selector.class
                } else if(flow.selector.attr){
                    classattr+=flow.selector.attr;
                }
        
                var cmd = "by.css('"+classattr+"')";
                return cmd;*/
                //console.log("element(by.css('"+flow.selector+"'))."+flow.event.name+"()");
                eval("element(by.css('" + flow.selector + "'))." + flow.event.name + "()");
            }

            this.id = function(flow) {
                /*var cmd = "by.id('"+flow.selector.id+"')";
                return cmd;*/
                eval("element(by.id('" + flow.selector + "'))." + flow.event.name + "()");
            }

            this.modelFlow = function(flow) {
                var cmd = "by.model('" + flow.selector.model + "')";
                return cmd;
            }

            this.form = function(type, data) {
                var selectors = form_selector[type + "_selector"];
                for (var selector in selectors) {
                    var value = selectors[selector];
                    this.model(value, data[selector]);
                }
            }

            this.body = function(flow, selector, event) {
                ////console.log(flow);
                var finder = (flow.selector != undefined && flow.selector.finderType != undefined) ? "." + flow.selector.finderType : "";
                var command = "element";
                command += finder + "(";
                command += selector + ")";
                command += event;
                return command;
            }

            this.event = function(flow) {
                var event = (flow.event != undefined && flow.event.name != undefined) ? flow.event.name : "";
                if (event != "") {
                    var argument = "(";
                    var params = (flow.event != undefined && flow.event.params != undefined) ? flow.event.params : [];
                    for (var param in params) {
                        var value = params[param];
                        argument += value;
                        if (params.length > param + 1)
                            argument += ",";
                    }
                    argument += ")";
                    return "." + event + argument;
                }
                return "";
            }

            this.flowControl = function(flowArray, type) {
                var steps = flowArray;
                for (var step in steps) {
                    console.log(steps[step])
                    eval("this." + steps[step]);
                }
            }

            this.clean=function(locatorType,locator,mode){

                 eval("element(by." + locator + "('" + locatorType + "')).clear()");
                if (mode == 'async')
                    browser.waitForAngular();
            }

           

            this.open_required_form = function(selectors, data, mode) {
                var form = ""
                temp_form_data = eval("form_data." + data);
                for (var key in temp_form_data["create"]) {
                    form = form + key + "|"
                    form = form.replace("_", " ")
                }
                console.log("Form " + form)


                element(by.model("formExist")).isPresent().then(function(addforms) {

                    if (addforms) {
                        element(by.model("formExist")).click();
                        console.log("Add Form clicked")
                        var i = 1;
                        element.all(by.repeater('match in $matches')).each(function(elem) {
                            var elem_form = element(by.xpath(".//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div/div[1]/ul/li[" + i + "]/a"))
                            elem_form.getText().then(function(formname) {
                                if (form.indexOf(formname) >= 0) {
                                    console.log("Form " + formname + "is added to request")
                                    elem_form.click();
                                } else console.log("Form is not present in drop down")
                            })
                            i++
                        })
                    } else console.log("Drop down is not present")


                });



                if (mode == 'async')
                    browser.waitForAngular(5000);

            }

       


            this.populate_create_form = function(selectors, data, mode) {

                var forms = form_selector[selectors];

                for (var form in forms) {
                    console.log("data : " + data)
                    
                    isFormExist(forms, form, selectors, data);
                }
                if (mode == 'async')
                    browser.waitForAngular();



            }


            isFormExist = function(forms, form, selectors, data) {


               // console.log("Current form is :" + form + "_tab")
                element(by.id(form + "_tab")).isPresent().then(function(present) {

                   // console.log("data : " + data)
                    var values = eval("form_data." + data);
                    if (present) {

                        console.log("form is present on screen")
                        element(by.id(form + "_tab")).isDisplayed().then(function(displayed) {

                            if (displayed) {
                                console.log(form + "_tab is diaplyed")
                                element(by.id(form + "_tab")).click();
                                var sections = forms[form];
                                //console.log("values: " + values)
                                //console.log("form :" + form)
                                console.log("Processing Form : " + form);

                                if (values["create"][form] instanceof Array) {
                                    console.log("$ " + values["create"][form])
                                    console.log(form + " has multiple Form.");
                                    var multi_form = values["create"][form];
                                    for (var one_form in multi_form) {
                                        for (var section in sections) {
                                            console.log("multi_form " + multi_form)
                                            console.log("$ " + form)

                                            isSectionExist(form, sections, section, data, true, one_form);
                                        }
                                        element(by.model(form)).click()
                                        var drop_down_count = element(by.model(form)).all(by.tagName("option")).count();
                                        console.log("######  " + multi_form.length)
                                        console.log("one_form " + one_form + "multi_form.length " + multi_form.length)
                                        if (!(one_form == multi_form.length - 1)) {
                                            element(by.css("[ng-click='addForm(\"" + form + "\")']")).click().then(function() {
                                                console.log("(i+1)" + (parseInt(one_form) + 1));
                                                element(by.model(form)).sendKeys(parseInt(one_form) + 1);
                                            });
                                        }
                                    }
                                } else {
                                    console.log(form + " has not multiple Form.");
                                    for (var section in sections) {
                                        isSectionExist(form, sections, section, data, false);
                                    }
                                }

                            } else {

                                console.log(form + " Form is not displayed")
                            }

                        })
                    } else {
                        console.log(form + " Form is not present on screen")
                    }

                })
            }

            isSectionExist = function(form, sections, section, data, repeating, formIndex) {
                var values = eval("form_data." + data);
                console.log(values)
                var j = 1;
                console.log("Section :" + sectionName(section));
                element(by.model(section)).isPresent().then(function(present) {
                    if (present) {
                        console.log("Model")
                        element(by.model(section)).click();
                    }
                });

                element(by.id(section)).isPresent().then(function(present) {
                    if (present) {
                        element(by.id(section)).getAttribute('class').then(function(classes) {
                            if (classes == "accordion-toggle section-closed") {
                                element(by.id(section)).click();

                            }

                        });
                    }

                });

                var fields = sections[section];

                console.log("Form Name : " + form + ", Section Name : " + sectionName(section));
                //  console.log(values["create"][form][sectionName] +" #####   "+form+" ####    "+sectionName)  
                console.log("form Index ----->  "+values["create"][form])
                if (values["create"][form] != undefined) {
                    console.log("formIndex" + formIndex)
                    var sectionVals = (formIndex != undefined) ? values["create"][form][formIndex][sectionName(section)] : values["create"][form][sectionName(section)];
                    console.log("Is a repeating section" + (sectionVals instanceof Array));
                    if (sectionVals instanceof Array) {
                        console.log("sectionVals --------- > " + sectionVals);
                        for (sectionVal in sectionVals) {
                            console.log("sectionVal :" + sectionVal);
                            for (var field in sectionVals[sectionVal]) {

                                checkElementState(fields[field], data, form, section, true, formIndex, sectionVal);
                            }
                            if ((sectionVals.length - 1) != parseInt(sectionVal)) {
                                element(by.xpath("//div[@name='" + form + "." + sectionName(section) + "']/fieldset/legend/span[3]")).isPresent().then(function(present) {
                                    if (present) {
                                        element(by.xpath("//div[@name='" + form + "." + sectionName(section) + "']/fieldset/legend/span[3]")).click().then(function() {
                                            element(by.model(sectionName(section))).sendKeys(parseInt(sectionVal) + 1);
                                        })
                                    }
                                });
                            }
                            console.log("(sectionVal+1)" + (parseInt(sectionVal) + 1));
                        }
                    } else {
                        for (var field in sectionVals) {
                            console.log("check point 0")
                            checkElementState(fields[field], data, form, section, false, formIndex);
                        }
                    }
                }
            }

            sectionName = function(section) {

                if (section == "EVC_UNIDETAIL")
                    return "EVC_unidetail";

                else if (section == "FGA_ServiceOptionSection")
                    return "FGA_serviceoptionsection";

                else if (section == "matrix")
                    return "matrix";

                else if (section == "circuitdetail")
                    return "CircuitDetail";
                else if (section == "cfa_requestheader")
                    return "RequestHeader"

                else {
                    console.log(section)
                    return section;
                }
            }

            checkElementState = function(field, data, form, section, repeating, formIndex, sectionIndex) {

                var values = eval("form_data." + data);
               // console.log("Current Section index:" + sectionIndex);
                var k = 1;
                //console.log(eval("form_data." + data))
                //console.log("values :     " + values)
                console.log("field   "+field)
                console.log("data   "+data)
                element(by.model(field)).isPresent().then(function(present) {
                    console.log(field + " is present :" + present);
                    if (present) {
                        element(by.model(field)).isDisplayed().then(function(display) {
                            if (display) {
                                console.log(field + " is displayed :" + display);
                                element(by.model(field)).isEnabled().then(function(enabled) {
                                    console.log(field + " is Enabled :" + enabled);
                                    //  console.log(actiononorder)

                                    if (actiononorder) {
                                        console.log("actiononorder   " + actiononorder)

                                        element(by.model(field)).getText().then(function(text) {
                                            console.log("text   " + text)
                                                //console.log(field)
                                            if (field.indexOf("SUP") >= 0) {
                                                console.log("inside if")
                                            } else if (text != null || text != "")
                                                element(by.model(field)).clear();
                                            else
                                                console.log("Inside Else ##")
                                        })
                                    }
                                    if (enabled) {
                                        console.log(enabled + " " + formIndex + " " + sectionIndex)

                                        if (formIndex == undefined && sectionIndex == undefined) {

                                            if (eval("values." + field).indexOf('globalpon') >= 0) {
                                                console.log(globalpon)
                                                element(by.model(field)).sendKeys(globalpon)
                                            } else if (eval("values." + field).indexOf('getValue') >= 0) {
                                                console.log("field " + field)
                                                temp_getValue = eval("values." + field)
                                                console.log("temp_getValue " + temp_getValue)
                                                getValue = eval(temp_getValue)
                                                console.log("Field: " + field.split(".")[3] + " getValue  " + getValue)

                                                element(by.model(field)).sendKeys(getValue);
                                            } else {


                                                element(by.model(field)).sendKeys(eval("values." + field))
                                            }
                                            //element(by.model(field)).sendKeys(eval("values."+field));
                                        } else {
                                            var fieldName = field.substring(field.lastIndexOf(".") + 1);
                                            var indexes = field.match(/\[.*\]/g);
                                            var cur_field = field;
                                            var i = 0;
                                            if (formIndex != undefined)
                                                cur_field = cur_field.replace(indexes[i++], "[" + formIndex + "]");
                                            if (sectionIndex != undefined)
                                                cur_field = cur_field.replace(indexes[i++], "[" + sectionIndex + "]");
                                            console.log("cur_field : " + cur_field);
                                            console.log("Value : " + eval("values." + cur_field));
                                            element(by.model(field)).sendKeys(eval("values." + cur_field));
                                        }
                                    }

                                });
                            }
                        });
                    }
                });
            }


            browser.sleep(3000);
            this.click_event = function(locator, locatorType, mode) {
                eval("element(by." + locator + "('" + locatorType + "')).click()");
                if (mode == 'async')
                    browser.waitForAngular();
            }

           

            this.click_options = function(locator, locatorType, index, event, mode) {
                eval("element.all(by." + locator + "('" + locatorType + "')).get(" + index + ")." + event + "()");
                if (mode == 'async')
                    browser.waitForAngular();
            }


            this.click_row = function(locator, locatorType, rowNum, columNum) {
                eval("element(by." + locator + "('" + locatorType + "').row(" + rowNum + ").column('" + columNum + "')).click()");
                browser.waitForAngular();
            }

            this.click_row_element = function(locatorType, element) {
                /*var command = "element(by.repeater('"+locatorType+"')).then(function(row){" +
                            "//console.log(row);row.findElement("+element+").click();"+
                        "})";*/
                ////console.log("element.all(by.repeater('"+locatorType+"').row(0)).findElement("+element+").click()");
                var command = "element(by.repeater('" + locatorType + "').row(0)).$('" + element + "').click()";
                //console.log(command);
                eval(command);
            }

            this.navigation_screen = function(option) {
                var flowArray = nav[option];
                for (var key in flowArray) {
                    var exe = true;
                    //var command = "element(";         
                    var command = "";
                    var flow = flowArray[key];
                    if (flow.locatorType == "css")
                        this.css(flow);
                    else if (flow.locatorType == "id")
                        this.id(flow);
                    else if (flow.locatorType == "model")
                        this.modelFlow(flow);
                }
            }

           

            this.expected_output = function(method, value, expected) {

                 element(by.id(section)).isPresent().then(function(present) {
                    if (present) {
                        element(by.id(section)).getAttribute('class').then(function(classes) {
                            if (classes == "accordion-toggle section-closed") {
                                element(by.id(section)).click();

                            }

                        });
                    }

                });
                
                console.log("expect(" + value + ")." + method + "('" + expected + "')");
                eval("expect(" + value + ")." + method + "('" + expected + "')");
            }

            this.verifySearchResult = function(repeatervalue, expected, mode) {

                element.all(by.repeater(repeatervalue)).then(function(posts) {
                    var i = 1

                    for (var post in posts) {
                        var elm = element.all(by.repeater(repeatervalue)).get(post);

                        element(elm.getText().then(function(text) {

                            //console.log("Search Result for Row "+i+" is : "+text);
                            i++;
                        }))

                        if (expected.split(",")) {

                            var expected_temp = expected.split(",")
                            for (count in expected_temp) {
                                expect(elm.getText()).toContain(expected_temp[count]);
                            }
                        } else {
                            expect(elm.getText()).toContain(expected);
                        }
                    }
                });

                if (mode == 'async')
                    browser.waitForAngular();
            }


            this.select = function(value) {
                var elem = element(by.model("applyAction[$index]"))
                elem.isPresent().then(function() {

                    elem.$("[value=\"" + value + "\"]").click();
                })

            }

        }



        module.exports = GenericFlow;

        if (dd >= 23) {
            dd = 0;
            dd = dd + parseInt(days)
            mm = mm + 1;

        } else {
            dd = dd + parseInt(days)
        }

        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }
        var today = mm + '-' + dd + '-' + yyyy;
        console.log("today is: " + today)
        return today

    }

    getValuePON = function(data) {

        globalpon = data + Math.floor((Math.random() * 1000000) + 1);
        return globalpon;
    }


    /*this.flow = function(selectFlow, type, data){
        ////console.log(flow_steps);
        data = eval("form_data."+data);
        var flow = eval("flow_steps."+selectFlow);
        ////console.log("flow_steps."+selectFlow);
        
        
        for(var key in flow)
        {
            ////console.log(key);
            var component = flow[key];
            ////console.log(component);
            this.flowControl(flow_comp[type+"_comp"][component], type, data);
        }
    };*/
     this.waitforPageToLoad = function(time){
        browser.pause();
                    browser.manage().timeouts().pageLoadTimeout(time);  
        }
clickElementfromMany = function(model, value)
        {                              
          element.all(by.model(model)).filter(function(elem, index) {
                                           return elem.isDisplayed().then(function (isDisplayed) {
                                                                        return isDisplayed;
                                                        });                                                           
                                        }).then(function(filteredElements) {                                       
                                                        return filteredElements[value].click();
                                        })
        }
    this.flow = function(selectFlow, type) {
        //console.log(flow_steps);      
        var flow = eval("flow_steps." + selectFlow + "." + type);
        console.log("flow_steps."+type);
        this.flowControl(flow, type);

    };
        this.click_button = function(buttonName){
            console.log("Button: "+buttonName)
            var button = driver.wait(until.elementLocated(By.buttonText(buttonName)), 50000);
    button.click();

           element(by.buttonText(buttonName)).click();
            browser.waitForAngular();
        };
    this.buttonText = function(key, value) {
        element(by.buttonText(key)).sendKeys(value);
        browser.waitForAngular();
    };
    this.model = function(key, value) {
        element(by.model(key)).sendKeys(value);
        browser.waitForAngular();
    };

    this.modelSet = function(modelArray) {
        for (var key in modelArray) {
            var model = modelArray[key];
            if (model.key instanceof Object)
                element.all(by.model(model.key)).get()
            this.model(model.key, model.value);
        }
    }

    this.repeater = function(flow) {
        var cmd = "by.repeater('" + flow.selector.repeater + "')";
        if (flow.repeater != undefined && flow.repeater.row != undefined)
            cmd += ".row(" + parseInt(flow.repeater.row) + ")";
        if (flow.repeater != undefined && flow.repeater.column != undefined)
            cmd += ".column(" + flow.repeater.column + ")";
        return cmd;
    }

    this.css = function(flow) {
        /*var classattr = "";
        if(flow.selector.class!=undefined){
            classattr+="."+flow.selector.class
        } else if(flow.selector.attr){
            classattr+=flow.selector.attr;
        }
        
        var cmd = "by.css('"+classattr+"')";
        return cmd;*/
        //console.log("element(by.css('"+flow.selector+"'))."+flow.event.name+"()");
        eval("element(by.css('" + flow.selector + "'))." + flow.event.name + "()");
    }

    this.id = function(flow) {
        /*var cmd = "by.id('"+flow.selector.id+"')";
        return cmd;*/
        eval("element(by.id('" + flow.selector + "'))." + flow.event.name + "()");
    }

    this.modelFlow = function(flow) {
        var cmd = "by.model('" + flow.selector.model + "')";
        return cmd;
    }

    this.form = function(type, data) {
        var selectors = form_selector[type + "_selector"];
        for (var selector in selectors) {
            var value = selectors[selector];
            this.model(value, data[selector]);
        }
    }

    this.body = function(flow, selector, event) {
        ////console.log(flow);
        var finder = (flow.selector != undefined && flow.selector.finderType != undefined) ? "." + flow.selector.finderType : "";
        var command = "element";
        command += finder + "(";
        command += selector + ")";
        command += event;
        return command;
    }

    this.event = function(flow) {
        var event = (flow.event != undefined && flow.event.name != undefined) ? flow.event.name : "";
        if (event != "") {
            var argument = "(";
            var params = (flow.event != undefined && flow.event.params != undefined) ? flow.event.params : [];
            for (var param in params) {
                var value = params[param];
                argument += value;
                if (params.length > param + 1)
                    argument += ",";
            }
            argument += ")";
            return "." + event + argument;
        }
        return "";
    }

    this.flowControl = function(flowArray, type) {
        var steps = flowArray;
        for (var step in steps) {
            //console.log("@@@   "+steps[step])
            eval("this." + steps[step]);
        }
    }

    browser.sleep(3000);
    this.populate_form = function(selectors, data, mode, action) {


        var models = form_selector[selectors];
        var values = eval("form_data." + data);
        //console.log("models::::  "+models)
        //console.log("values::::  "+values)
        for (var value in values) {
            if (values[value] instanceof Object) {

                //console.log("Field Name 1:" + models[value] + ",  Value :" + values[value]["index"]);
                clickElementfromMany(models[value], values[value]["index"]);


            } else {
               
                        if (action) {
                            console.log("action" + action)
                            actiononorder = action
                        }
                       // console.log("values[value]" + values[value])

                        if (values[value].indexOf("pon") >= 0) {
                            //console.log("values[value]  "+ values[value])

                            //console.log("globalpon: "+globalpon)
                          //  console.log("Checkpoint1")
                            element(by.model(models[value])).sendKeys(globalpon);

                        }  if (values[value].indexOf("getValue") >= 0) {
                            //console.log("Checkpoint3")
                            element(by.model(models[value])).sendKeys(eval(values[value]))
                        } 
                                
                         element(by.model(models[value])).sendKeys((values[value]))
                   
            
            
                

            }
        }

        if (mode == 'async')
            browser.waitForAngular();
    };


    this.populate_login_form = function(selectors, data, mode, action) {
          var models = form_selector[selectors];
        var values = eval("form_data." + data);
         for (var value in values) {
            console.log("Fields ---> "+models[value]+"  Value ---> "+values[value])
             element(by.model(models[value])).sendKeys(values[value]);  
         }

    }

    this.open_required_form = function(selectors, data, mode) {
        var form = ""
        temp_form_data = eval("form_data." + data);
        for (var key in temp_form_data["create"]) {
            form = form + key + "|"
            form = form.replace("_", " ")
        }
        console.log("Form " + form)


        element(by.model("formExist")).isPresent().then(function(addforms) {

            if (addforms) {
                element(by.model("formExist")).click();
                console.log("Add Form clicked")
                var i = 1;
                element.all(by.repeater('match in $matches')).each(function(elem) {
                    var elem_form = element(by.xpath(".//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div/div[1]/ul/li[" + i + "]/a"))
                    elem_form.getText().then(function(formname) {
                        if (form.indexOf(formname) >= 0) {
                            console.log("Form " + formname + "is added to request")
                            elem_form.click();
                        } else console.log("Form is not present in drop down")
                    })
                    i++
                })
            } else console.log("Drop down is not present")


        });



        if (mode == 'async')
            browser.waitForAngular(5000);

    }

    this.populate_create_form = function(selectors, data, mode) {

        var forms = form_selector[selectors];

        for (var form in forms) {
            
            isFormExist(forms, form, selectors, data);
        }
        if (mode == 'async')
            browser.waitForAngular();



    }


    isFormExist = function(forms, form, selectors, data) {


      //  console.log("Current form is :" + form + "_tab")

        element(by.id(form + "_tab")).isPresent().then(function(present) {
            console.log("Processing Form : " + form);
            
            var values = eval("form_data." + data);
            if (present) {

                console.log("form is present on screen")
                element(by.id(form + "_tab")).isDisplayed().then(function(displayed) {

                    if (displayed) {
                        console.log(form + "_tab is diaplyed")
                        element(by.id(form + "_tab")).click();
                        var sections = forms[form];
                        console.log("values: " + values)
                        console.log("form :" + form)
                       var key, count = 0;
                        for(key in values["create"][form]) {
  
                                 count++;
  
                            }
                        console.log("Number Of Forms--------> :    "+count)
                        if (values["create"][form] instanceof Array) {
                            console.log("$ " + values["create"][form])
                            console.log(form + " has multiple Form.");
                            var multi_form = values["create"][form];
                            for (var one_form in multi_form) {
                                for (var section in sections) {
                                    console.log("multi_form " + multi_form)
                                    console.log("$ " + form)

                                    isSectionExist(form, sections, section, data, true, one_form);
                                }
                                element(by.model(form)).click()
                                var drop_down_count = element(by.model(form)).all(by.tagName("option")).count();
                               // console.log("###########################  " + drop_down_count+"###############    "+count)

                                //console.log("one_form " + one_form + "multi_form.length " + multi_form.length)
                               
                                if (!(one_form == multi_form.length - 1)) {
                                     element(by.css("[ng-click='addForm(\"" + form + "\")']")).click().then(function(){
                                    element(by.model(form)).sendKeys(parseInt(one_form) + 1)
                                     })
                                    
                                    
                                }
                            }
                        } else {
                            console.log(form + " has not multiple Form.");
                            for (var section in sections) {
                                isSectionExist(form, sections, section, data, false);
                            }
                        }

                    } else {

                        console.log(form + " Form is not displayed")
                    }

                })
            } else {
                console.log(form + " Form is not present on screen")
            }

        })
    }

    isSectionExist = function(form, sections, section, data, repeating, formIndex) {
        var values = eval("form_data." + data);
        //console.log(values)
        var j = 1;
        console.log("Section :" + sectionName(section));
        element(by.model(section)).isPresent().then(function(present) {
            if (present) {
                element(by.model(section)).click();
            }
        });

        element(by.id(section)).isPresent().then(function(present) {
            if (present) {
                element(by.id(section)).getAttribute('class').then(function(classes) {
                    if (classes == "accordion-toggle section-closed") {
                        element(by.id(section)).click();

                    }

                });
            }

        });

        var fields = sections[section];

        console.log("Form Name : " + form + ", Section Name : " + sectionName(section)+"  ,Fields   "+fields);
            //console.log(values["create"][form][sectionName] +" #####   "+form+" ####    "+sectionName)    
        if (values["create"][form] != undefined) {
            console.log("formIndex  " + formIndex)
            var sectionVals = (formIndex != undefined) ? values["create"][form][formIndex][sectionName(section)] : values["create"][form][sectionName(section)];
            console.log("Is a repeating section  " + (sectionVals instanceof Array));
            if (sectionVals instanceof Array) {
                console.log("sectionVals --------- > " + sectionVals);
                for (sectionVal in sectionVals) {
                    if(sectionVal instanceof Array){
                        for(subsectionval in sectionval[subsectionval]){
                            console.log("subsectionval --->"+subsectionval)
                            console.log("fields[field] -->"+fields[field])
                            checkElementState(fields[field], data, form, section, true, formIndex, sectionVal,subsectionval);
                        }
                    }
                    console.log("sectionVal :" + sectionVal);
                    for (var field in sectionVals[sectionVal]) {

                        checkElementState(fields[field], data, form, section, true, formIndex, sectionVal);
                    }
                    if ((sectionVals.length - 1) != parseInt(sectionVal)) {
                        element(by.xpath("//div[@name='" + form + "." + sectionName(section) + "']/fieldset/legend/span[3]")).isPresent().then(function(present) {
                            if (present) {
                                element(by.xpath("//div[@name='" + form + "." + sectionName(section) + "']/fieldset/legend/span[3]")).click().then(function() {
                                    element(by.model(sectionName(section))).sendKeys(parseInt(sectionVal) + 1);
                                })
                            }
                        });
                    }
                    console.log("(sectionVal+1)" + (parseInt(sectionVal) + 1));
                }
            } else {
               console.log("Check Point 1")
                console.log("field  ---> "+fields[field])
                console.log("sectionVals  ---> "+ sectionVals)
                for (var field in sectionVals) {
                    console.log("Check Point 2")
                   // console.log("sectionvals[field]  "+sectionvals[field])
                    console.log("field  ---> "+fields[field])
                    checkElementState(fields[field], data, form, section, false, formIndex);
                }
            }
        }
    }

    sectionName = function(section) {
        if (section == "EVC_UNIDETAIL")
            return "EVC_unidetail";

        else if (section == "FGA_ServiceOptionSection")
            return "FGA_serviceoptionsection";

        else if (section == "matrix")
            return "matrix";

        else if (section == "circuitdetail")
            return "CircuitDetail";

        else {
            console.log(section)
            return section;
        }
    }

    checkElementState = function(field, data, form, section, repeating, formIndex, sectionIndex,subsectionIndex) {
        
        console.log("field:    " +field);
        console.log("data:     "+data)
        var values = eval("form_data." + data);
        console.log("Current Section index:" + sectionIndex);
        var k = 1;
       // console.log(eval("form_data." + data))
     //   console.log("values :     " + values)

        element(by.model(field)).isPresent().then(function(present) {
            console.log(field + " is present :" + present);
            if (present) {
                element(by.model(field)).isDisplayed().then(function(display) {
                    if (display) {
                        console.log(field + " is displayed :" + display);
                        element(by.model(field)).isEnabled().then(function(enabled) {
                            console.log(field + " is Enabled :" + enabled);
                            //  console.log(actiononorder)

                            if (actiononorder) {
                                console.log("actiononorder   " + actiononorder)

                                element(by.model(field)).getText().then(function(text) {
                                    console.log("text   " + text)
                                        //console.log(field)
                                    if (field.indexOf("SUP") >= 0) {
                                        console.log("inside if")
                                    } else if (text != null || text != "")
                                        element(by.model(field)).clear();
                                    else
                                        console.log("Inside Else ##")
                                })
                            }
                            if (enabled) {
                                console.log("field ---->"+field)
                                console.log("values --->"+values)
                                console.log(enabled + " " + formIndex + " " + sectionIndex)
                                //console.log(enabled + " " + formIndex + " " + subsectionIndex)
                                    
                                if (formIndex == undefined && sectionIndex == undefined) {
                                    
                                    if (eval("values." + field).indexOf('globalpon') >= 0) {
                                        console.log(globalpon)
                                        element(by.model(field)).sendKeys(globalpon)
                                    } else if (eval("values." + field).indexOf('getValue') >= 0) {
                                        console.log("field " + field)
                                        temp_getValue = eval("values." + field)
                                        console.log("temp_getValue " + temp_getValue)
                                        getValue = eval(temp_getValue)
                                        console.log("Field: " + field.split(".")[3] + " getValue  " + getValue)
                                        element(by.model(field)).sendKeys(getValue);
                                    } else {

                                        console.log("field ===>" +field)
                                        if(eval("values." + field) == "")
                                            element(by.model(field)).clear()
                                        else
                                        element(by.model(field)).sendKeys(eval("values." + field))
                                    }
                                    //element(by.model(field)).sendKeys(eval("values."+field));
                                } else {
                                    console.log("checkpoint 3")
                                    var fieldName = field.substring(field.lastIndexOf(".") + 1);
                                    var indexes = field.match(/\[.*\]/g);
                                    var cur_field = field;
                                    console.log("cur_field  ------>>>>"+cur_field)
                                    var i = 0;
                                    if (formIndex != undefined)
                                        cur_field = cur_field.replace(indexes[i++], "[" + formIndex + "]");
                                    if (sectionIndex != undefined)
                                        cur_field = cur_field.replace(indexes[i++], "[" + sectionIndex + "]");
                                    if(subsectionIndex != undefined)
                                        cur_field.replace(indexes[i++], "[" + subsectionIndex + "]");
                                       
                                    console.log("cur_field : " + cur_field);
                                    console.log("Value : " + eval("values." + cur_field));
                                    if(eval("values." + cur_field)== "")
                                         element(by.model(field)).clear()
                                   
                                else
                                    element(by.model(field)).sendKeys(eval("values." + cur_field));


                                }
                            }

                        });
                    }
                });
            }
        });
    }


    browser.sleep(3000);
    this.click_event = function(locator, locatorType, mode) {
       // console.log("locator -->"+locator+"    locatorType --> "+ locatorType);

       eval("element(by." + locator + "('" + locatorType + "'))").isPresent().then(function(present){
        eval("element(by." + locator + "('" + locatorType + "')).click()");    
        })

        
        if (mode == 'async')
            browser.waitForAngular();
    }

    this.verify_message  = function(){
         // var switchElem = element(by.css("//*[@id=\"toast-container\"]/div/div[2]/div"))
                console.log("$$$$$ " +element(by.css("//*[@id=\"toast-container\"]/div/div[2]/div")).getText());
    }

    this.click_options = function(locator, locatorType, index, event, mode) {
        eval("element.all(by." + locator + "('" + locatorType + "')).get(" + index + ")." + event + "()");
        if (mode == 'async')
            browser.waitForAngular();
    }


    this.click_row = function(locator, locatorType, rowNum, columNum) {
        eval("element(by." + locator + "('" + locatorType + "').row(" + rowNum + ").column('" + columNum + "')).click()");
        browser.waitForAngular();
    }

    this.click_row_element = function(locatorType, element) {
        /*var command = "element(by.repeater('"+locatorType+"')).then(function(row){" +
                    "//console.log(row);row.findElement("+element+").click();"+
                "})";*/
        ////console.log("element.all(by.repeater('"+locatorType+"').row(0)).findElement("+element+").click()");
        var command = "element(by.repeater('" + locatorType + "').row(0)).$('" + element + "').click()";
        //console.log(command);
        eval(command);
    }

    this.navigation_screen = function(option) {
        var flowArray = nav[option];
        for (var key in flowArray) {
            var exe = true;
            //var command = "element(";         
            var command = "";
            var flow = flowArray[key];
            if (flow.locatorType == "css")
                this.css(flow);
            else if (flow.locatorType == "id")
                this.id(flow);
            else if (flow.locatorType == "model")
                this.modelFlow(flow);
        }
    }

    this.expected_output = function(method, value, expected) {
        console.log("method -- >"+method)
        console.log("value -- > " +value)
        console.log("expected -- >"+expected)
        console.log("expect(" + value + ")." + method + "('" + expected + "')");
        eval("expect(" + value + ")." + method + "('" + expected + "')");
    }

    this.verifySearchResult = function(repeatervalue, expected, mode) {

        element.all(by.repeater(repeatervalue)).then(function(posts) {
            var i = 1

            for (var post in posts) {
                var elm = element.all(by.repeater(repeatervalue)).get(post);

                element(elm.getText().then(function(text) {

                    //console.log("Search Result for Row "+i+" is : "+text);
                    i++;
                }))

                if (expected.split(",")) {

                    var expected_temp = expected.split(",")
                    for (count in expected_temp) {
                        expect(elm.getText()).toContain(expected_temp[count]);
                    }
                } else {
                    expect(elm.getText()).toContain(expected);
                }
            }
        });

        if (mode == 'async')
            browser.waitForAngular();
    }


   this.selectTradingPartner = function(value) {
        var elem = element(by.name("TP"))

        elem.isPresent().then(function() {
            console.log("present...")

            elem.$("[value=\"" + value + "\"]").click();
        })
    }
    

     this.selectDropDown = function ( ) {
    if ('1'){
      var options = element.findElements(by.tagName('option'))   
        .then(function(options){
          options[1].click();
        });
    }
  };

    this.selectRadioButton= function(locator,locator_type,value,mode){
        console.log(locator_type+"('"+locator+")")




        eval("element.all(by."+locator_type+"('"+locator+"'))").then(function (elm) {
            //console.log(elm)
            if(elm)
            elm.get[0].click();
    })

        if (mode =='async'){
            browser.waitForAngular()
        }
    }


}



module.exports = GenericFlow;