var ValueMap = require('./Constants.PO.js');
var FlowJson = require('./Flow.js');
var UserTestService = require('./user_mgmt_container.js');
var CommonFunction = require('./generic_function.js');
var GenericFlow = require('./generic_flow_controller.js');
describe('user login form', function() {
	var ptro;
	var params = browser.params;  
	var valueMap = new ValueMap();  		
	console.log(CommonFunction);
	var flowJson = new FlowJson();  	
	var commonFunction = new CommonFunction();  	
	var genericFlow = new GenericFlow();  	
	
	var http = require('http');
	beforeEach(function(){
		browser.get(params.url.baseUrl+'login');
		console.log(params.url.baseUrl+'login');
		genericFlow.flow("login_flow", "login");
	});
  
  
  it('Test - Search a role ', function(){	
	genericFlow.flow("role_flow", "search");	       
  });
  
  it('Test assign role to the user', function(){	
		genericFlow.flow("role_flow", "add");	       
  });
  
  it('Test assign role to the user', function(){	
		genericFlow.flow("role_flow", "assign_subrole");	       
  });
	
	it('Test disable user', function(){	
		genericFlow.flow("role_flow", "unassign_subrole");	       
	});
	
	it('Test enable user', function(){	
		genericFlow.flow("role_flow", "assign_permission");	       
	});
	it('Test enable user', function(){	
		genericFlow.flow("role_flow", "assign_permission");	       
	});
		
  
});