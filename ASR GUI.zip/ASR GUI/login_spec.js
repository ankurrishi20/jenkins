var GenericFlow = require('./generic_flow_controller.js');

describe('user login form', function() {
	
	var ptro;
	var params = browser.params;    		
	var genericFlow = new GenericFlow();  	
	var http = require('http');

	browser.get(params.url.baseUrl+'login');
	browser.driver.manage().window().maximize();		
	console.log(params.url.baseUrl+'login');
	
	beforeEach(function(){
		genericFlow.flow("login_flow", "login");
	});
		
	

	 afterEach(function(){
		genericFlow.flow("logout_flow", "logout");
	}); 

	 
  
	it('Test create order request EVC Standalone', function(){	
		genericFlow.flow("create_order_flow", "evcStandalone");	       
	});
 
	it('Test create order request UNI-EU', function(){	
		genericFlow.flow("create_order_flow", "unieu");	       
	});

it('Test create order request UNI-EU', function(){	
		genericFlow.flow("create_order_flow", "unieuevc");	       
	});

it('Test create order request UNI-EU', function(){	
		genericFlow.flow("create_order_flow", "uninnipop");	       
	});

it('Test create order request UNI-EU', function(){	
		genericFlow.flow("create_order_flow", "uninnipopevc");	       
	});




	  
});