// An example configuration file.

var env = require('./environment.js');

exports.config = {
		directConnect: true,
  // The address of a running selenium server.
  seleniumAddress: env.seleniumAddress,
  params : {
    url :{
      baseUrl : env.baseUrl,
      corsUrl : env.corsUrl
    }
  },
  // Capabilities to be passed to the webdriver instance.
  capabilities: env.capabilities,

  // Spec patterns are relative to the current working directly when
  // protractor is called.
  specs: [
  'create_order_spec.js'
  ],
 
 // Options to be passed to Jasmine-node.
  framework: 'jasmine2',
  jasmineNodeOpts: {
    showColors: true,
    allScriptsTimeout: 600000,
    defaultTimeoutInterval: 1500000
  },
  onPrepare: function() {
    getPageTimeout:50000;
    allScriptsTimeout:50000
     browser.manage().timeouts().pageLoadTimeout(30000);
      browser.manage().timeouts().implicitlyWait(2000);
      browser.manage().timeouts().implicitlyWait(4000);
    browser.manage().timeouts().setScriptTimeout(30000);
       var HtmlReporter = require('protractor-html-screenshot-reporter');
    var reporter = new HtmlReporter({
    baseDirectory: '../results', // a location to store screen shots.
    docTitle: 'ASR GUI Test Execution Report',
    docName: 'tests-report.html'
    });
    jasmine.getEnv().addReporter(reporter);
    }
};