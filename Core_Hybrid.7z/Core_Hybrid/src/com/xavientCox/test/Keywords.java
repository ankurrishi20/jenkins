package com.xavientCox.test;

import static com.xavientCox.test.DriverScript.APP_LOGS;
import static com.xavientCox.test.DriverScript.CONFIG;
import static com.xavientCox.test.DriverScript.OR;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

//one function per keyword
public class Keywords {

	public WebDriver driver;

	public String openBrowser(String object, String data) {
		try {
			System.out.println("opening the browser");

			if (CONFIG.getProperty(data).equals("Mozilla"))
				driver = new FirefoxDriver();
			else if (CONFIG.getProperty(data).equals("IE")) {
				System.setProperty("webdriver.ie.driver",
						"D://jarAndDriver//IEDriverServer.exe");
				driver = new InternetExplorerDriver();
			} else if (CONFIG.getProperty(data).equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver",
						"D://jarAndDriver//chromedriver.exe");
				driver = new ChromeDriver();
			}

			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String navigate(String object, String data) {
		System.out.println("Navigating to URL");

		try {
			driver.navigate().to(CONFIG.getProperty(data));
			driver.manage().window().maximize();
			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL + "--Not able to navigate";

		}

	}

	public String clickLink(String object, String data)
			throws InterruptedException {
		try {
			System.out.println("Clicking on link ");
			Thread.sleep(3000);
			driver.findElement(By.xpath(OR.getProperty(object))).click();
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL + "--Not able to Click";
		}

	}

	public String verifyLinkText() {

		return Constants.KEYWORD_PASS;

	}

	public String clickButton() {
		System.out.println("Clicking on Button");

		return Constants.KEYWORD_PASS;
	}

	public String verifyButtonText() {
		System.out.println("Verifying the button text");

		return Constants.KEYWORD_PASS;
	}

	public String selectList(String object, String data) {

		try {
			System.out.println("Selecting from list");

			// driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);;
			Select dropdown = new Select(driver.findElement(By.xpath(OR
					.getProperty(object))));

			dropdown.selectByVisibleText(data);
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {

			System.out.println(e);
			e.printStackTrace();
			return Constants.KEYWORD_FAIL;
		}

	}

	public String selectListbyIndex(String object, String data) {

		try {
			System.out.println("Selecting from list");
			Select dropdown = new Select(driver.findElement(By.xpath(OR
					.getProperty(object))));
			
			int y = Integer.parseInt(data);
			
			
			dropdown.selectByIndex(y);
			return Constants.KEYWORD_PASS;

			// WebElement mySelectElm = driver.findElement(By.id("mySelectID"));
			// Select mySelect= new Select(mySelectElm);
			// selMySelect.selectByIndex(0);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return Constants.KEYWORD_FAIL;
		}

	}

	public String verifyListSelection() {
		System.out.println("Verifying the selection of the list");

		return Constants.KEYWORD_PASS;
	}

	public String verifyAllListElements() {
		System.out.println("Verifying all the list elements");

		return Constants.KEYWORD_PASS;

	}

	public String selectRadio(String object, String data) {

		try {
			System.out.println("-----Selecting the Radio-------");
			List<WebElement> radio = new ArrayList<WebElement>();
			radio = driver.findElements(By.name(OR.getProperty(object)));
			int Intdata = Integer.parseInt(data);
			radio.get(Intdata - 1).click();
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String selectCheckBox(String object, String data) {

		try {

			List<WebElement> radio = new ArrayList<WebElement>();
			radio = driver.findElements(By.name(OR.getProperty(object)));
			int Intdata = Integer.parseInt(data);
			radio.get(Intdata - 1).click();
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String verifyRadioSelected() {
		System.out.println("Verify Radio Selected");

		return Constants.KEYWORD_PASS;

	}

	public String verifyCheckBoxSelected() {
		System.out.println("Verifying checkbox selected");

		return Constants.KEYWORD_PASS;

	}

	public String IsEnabled(String object, String data) {
		System.out.println("Verifying element is enabled..");

		WebElement element = driver
				.findElement(By.xpath(OR.getProperty(object)));
		boolean bool = element.isEnabled();

		if (bool) {
			return Constants.KEYWORD_PASS;

		} else {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String IsDisabled(String object, String data) {
		System.out.println("Verifying element is Disabled..");

		WebElement element = driver
				.findElement(By.xpath(OR.getProperty(object)));
		boolean bool = element.isEnabled();

		if (bool) {
			return Constants.KEYWORD_FAIL;

		} else {
			return Constants.KEYWORD_PASS;
		}

	}

	public String verifyText(String object, String data) {
		try {
			System.out.println("Verifying the text");
			String TextfromWeb = driver.findElement(
					By.xpath(OR.getProperty(object))).getText();
			String TextfromSheet = data;
			if (TextfromWeb.equals(TextfromSheet)) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL;
			}
		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String writeInInput(String object, String data) {

		try {

			System.out.println("Writing in Input box");
			Thread.sleep(3000L);
			driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
			// driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(Keys.ENTER);

			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;

		}

	}

	public String verifyTextinInput(String object, String data) {
		System.out.println("Verifying the text in input box");

		return Constants.KEYWORD_PASS;
	}

	public String clickImage(String object, String data) {
		System.out.println("Clicking the image");

		return Constants.KEYWORD_PASS;
	}

	public String verifyFileName(String object, String data) {
		System.out.println("Verifying inage filename");

		return Constants.KEYWORD_PASS;
	}

	public String pause(String object, String data) {
		try {

			System.out.println("Waiting---Executing pause");

			if (data.equals("LOW") || data.equals("low") || data.equals("Low"))
				Thread.sleep(2000);
			else if (data.equals("MEDIUM") || data.equals("medium")
					|| data.equals("Medium")) {
				Thread.sleep(4000);
			} else if (data.equals("HIGH") || data.equals("high")
					|| data.equals("High")) {
				Thread.sleep(6000);
			}

			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String store(String object, String data) {
		System.out.println("Storing value");

		return Constants.KEYWORD_PASS;
	}

	public String verifyTitle(String object, String data) {
		System.out.println("Verifying title");

		return Constants.KEYWORD_PASS;
	}

	public String exist(String object, String data) {
		System.out.println("Checking existance of element");

		try {

			if (driver.findElement(By.xpath(OR.getProperty(object)))
					.isDisplayed()) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL;
			}
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String logout(String object, String data) {
		System.out.println("logging out.......");
		driver.findElement(By.xpath(OR.getProperty(object))).click();
		return Constants.KEYWORD_PASS;
	}

	public String click(String object, String data) {
		try {

			System.out.println("Clicking on any element");
			driver.findElement(By.xpath(OR.getProperty(object))).click();
			Thread.sleep(5000L);
			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String clickbtn(String object, String data) {
		try {

			System.out.println("-----clicking button------");

			driver.findElement(By.xpath(OR.getProperty(object))).click();
			Thread.sleep(5000L);
			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String verifypresent(String object, String data) {
		try {

			System.out.println("-----Verifying presence of Element------");

			if (driver.findElement(By.xpath(OR.getProperty(object)))
					.isDisplayed()) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL + "Element is not displayed";
			}

		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String writeInputAndEnter(String object, String data) {
		try {

			System.out.println("Executing write and Enter");
			System.out.println(object);
			System.out.println(data);
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(By.xpath(OR
					.getProperty(object))));
			actions.click();
			actions.sendKeys(data);
			actions.sendKeys(Keys.ENTER);
			actions.build().perform();
			System.out.println("finishing write and Enter");
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {

			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}

	}

	public String synchronize(String object, String data) {
		System.out.println("Waiting for page to load");

		return Constants.KEYWORD_PASS;
	}

	public String locateAndclick(String object, String data) {
		try {
			WebElement element = driver.findElement(By.xpath(object));

			Actions actions = new Actions(driver);

			actions.moveToElement(element).click().perform();
			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}
	}

	public String waitForElementVisibility(String object, String data) {
		System.out.println("Waiting for an elelement to be visible");

		return Constants.KEYWORD_PASS;
	}

	public String closeBroswer(String object, String data) {
		try {
			System.out.println("Closing the browser");
			driver.close();
			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String ScrollDown(String object, String data) {
		try {
			System.out.println("Scrolling the browser");
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String ScrollToTop(String object, String data) {
		try {
			System.out.println("Scrolling to the TOP browser");
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("scroll(250, 0)");
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			System.out.println(e);
			return Constants.KEYWORD_FAIL;
		}
	}

	public String ScrollDownTillLast(String object, String data) {
		try {

			JavascriptExecutor javascript = (JavascriptExecutor) driver;
			javascript.executeScript(
					"window.scrollTo(0, document.body.scrollHeight)", "");
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String clear(String object, String data) {
		try {

			driver.findElement(By.xpath(OR.getProperty(object))).clear();
			return Constants.KEYWORD_PASS;

		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String verifyErrorMessage(String object, String data) {
		try {

			String ExpectedMessage = driver.findElement(
					By.xpath(OR.getProperty(object))).getText();
			String ActualMessage = data;

			if (ExpectedMessage.contains(ActualMessage)
					|| ActualMessage.contains(ExpectedMessage)) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL;
			}

		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String mouseOver(String object, String data) {

		try {
			System.out.println("Mouse Over the menu");
			System.out.println("Object is-->" + object);
			String objectvalue = OR.getProperty(object);
			System.out.println("objectvalue-->" + objectvalue);
			String[] parts = OR.getProperty(object).split("\\|");
			String part1 = parts[0];
			String part2 = parts[1];
			System.out.println(part1);
			System.out.println(part2);
			Actions action = new Actions(driver);
			WebElement myElement = driver.findElement(By.xpath(part1));
			action.moveToElement(myElement)
					.moveToElement(driver.findElement(By.xpath(part2))).click()
					.build().perform();
			Thread.sleep(3000);
			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String mouseOverTwice(String object, String data) {

		try {
			System.out.println("--Mouse over Twice Rules--->");
			String[] parts = OR.getProperty(object).split("\\|");
			String part1 = parts[0];
			String part2 = parts[1];
			String part3 = parts[2];
			System.out.println(part1);
			System.out.println(part2);
			System.out.println(part3);
			Point coordinates = driver.findElement(By.xpath(part1))
					.getLocation();
			Robot robot = new Robot();
			robot.mouseMove(coordinates.getX(), coordinates.getY() + 70);
			Point coordinates1 = driver.findElement(By.xpath(part2))
					.getLocation();
			robot.mouseMove(coordinates1.getX(), coordinates1.getY() + 85);
			WebElement Submenu = driver.findElement(By.xpath(part3));
			Submenu.click();
			return Constants.KEYWORD_PASS;
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	public String verifyAddedElement(String object, String data) {
		try {

			String result = "Fail";
			WebElement we = driver
					.findElement(By.xpath(OR.getProperty(object)));
			List<WebElement> list = new ArrayList<WebElement>();
			list = we.findElements(By.tagName("td"));
			for (int i = 0; i < list.size(); i++) {
				String str = list.get(i).getText();

				if (str.equalsIgnoreCase(data)) {
					result = "Pass";
				}

			}
			if (result.equalsIgnoreCase("Pass")) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL + "No match found";
			}

		}

		catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}

	/************************ APPLICATION SPECIFIC KEYWORDS ********************************/

	public String verifyStatus(String object, String data) {
		try {
			System.out.println("---Verifying the Status---");
			String Actual = driver
					.findElement(By.xpath(OR.getProperty(object)))
					.getAttribute("src");
			String Expected = data;

			System.out.println("Actual value--->" + Actual);

			System.out.println("Expected value--->" + Expected);
			if (Actual.contains(Expected) || Expected.contains(Actual)) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL;
			}
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}
	
	public String SortFirstRecordToDeactivate(String object, String data) {
		try {
            
			
			System.out.println("Executing SortFirstRecordToDeactivate ");
			String[] parts = OR.getProperty(object).split("\\|");
			String part1 = parts[0];
			String part2 = parts[1];
			
			String value=driver.findElement(By.xpath(part1)).getText();
			
			System.out.println(value);
			if(value.equals("A"))
			{
				Actions action =new Actions(driver);
				
				WebElement we=driver.findElement(By.xpath(part2));
				
				action.doubleClick(we);
				
			
			}
			return Constants.KEYWORD_PASS;
			
		
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}
	
	
	public String SortFirstRecordToActivate(String object, String data) {
		try {
                
			String[] parts = OR.getProperty(object).split("\\|");
			String part1 = parts[0];
			String part2 = parts[1];
			
			String Value=driver.findElement(By.xpath(part1)).getText();
			
			if(Value.equals("D"))
			{
                Actions action =new Actions(driver);
				
				WebElement we=driver.findElement(By.xpath(part2));
				
				action.doubleClick(we);
			
			}
			return Constants.KEYWORD_PASS;
		
		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}
	
	public String moveMouseToRight(String object, String data) {
		try {

			Boolean flag = false;
			Actions action = new Actions(driver);

			// action.click(webElement).build().perform();
			Thread.sleep(1000);
			for (int i = 0; i < 10; i++) {
				action.sendKeys(Keys.ARROW_RIGHT).build().perform();
				Thread.sleep(200);
				flag = true;
			}

			if (flag) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL;
			}

		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}
	
	public String moveMouseToLeft(String object, String data) {
		try {

			Boolean flag = false;
			Actions action = new Actions(driver);

			// action.click(webElement).build().perform();
			Thread.sleep(1000);
			for (int i = 0; i < 10; i++) {
				action.sendKeys(Keys.ARROW_LEFT).build().perform();
				Thread.sleep(200);
				flag = true;
			}

			if (flag) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL;
			}

		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}
	
	public String selectFromNth(String object, String data) {
		try {

			Boolean flag = false;
			Actions action = new Actions(driver);

			// action.click(webElement).build().perform();
			Thread.sleep(1000);
			for (int i = 0; i < 10; i++) {
				action.sendKeys(Keys.ARROW_LEFT).build().perform();
				Thread.sleep(200);
				flag = true;
			}

			if (flag) {
				return Constants.KEYWORD_PASS;
			} else {
				return Constants.KEYWORD_FAIL;
			}

		} catch (Exception e) {
			return Constants.KEYWORD_FAIL;
		}

	}
	
	
	
}
